const express = require('express');
const fetch = require('node-fetch');
const path = require('path');
const app = express();
const http = require('http');
const socketIo = require('socket.io');
const port = 3000;

const API_KEY = 'e54e6ee5ba41150b7a8e2ee6a87b811c';
const WEATHER_API_URL = 'https://api.openweathermap.org/data/2.5/weather';

const server = http.createServer(app);
const io = socketIo(server);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/', (req, res) => {
  res.render('main');
});

app.get('/todo', (req, res) => {
res.render('todo');
});

app.get('/getWeather', async (req, res) => {
    const cityName = req.query.city;
    const weatherApiUrl = `${WEATHER_API_URL}?q=${encodeURIComponent(cityName)}&appid=${API_KEY}&units=metric`;
    
    const response = await fetch(weatherApiUrl);
    const data = await response.json();
  
    res.json(data);
});

app.get('/weather', (req, res) => {
res.render('weather');
});

app.get('/chat', (req, res) => {
res.render('chat');
});


const users = [];

io.on('connection', (socket) => {
  
  socket.on('new user', (nickname) => {
    // 유저 접속하면 사방팔방에 알림.
    // 클라이언트쪽을 위해 nickname을 socket.nickname에 저장.
    users.push(nickname);
    io.emit('user list', users);
    socket.nickname = nickname;
    io.emit('chat message', { msg: `${nickname} 이/가 채팅에 참여했습니다.`, nickname: '시스템' });
  });

  socket.on('chat message', (data) => {
    // 전송받은 메세지를 모든 유저에게 전송.
    io.emit('chat message', data);
  });

  socket.on('disconnect', () => {
    // 유저 나갔을때 모두에게 알림.
    const index = users.indexOf(socket.nickname);
    if(index > -1) {
      users.splice(index, 1);
    }
    io.emit('user list', users);
    io.emit('chat message', { msg: `${socket.nickname} 이/가 채팅을 떠났습니다.`, nickname: '시스템' });
  });
});

server.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
